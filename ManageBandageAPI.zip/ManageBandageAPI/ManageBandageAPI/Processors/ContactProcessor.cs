﻿using ManageBandageAPI.Models;
using ManageBandageAPI.Repositories;

namespace ManageBandageAPI.Processors
{
    public class ContactProcessor
    {
        public static bool UserLogin(User user)
        {
            return ContactRepository.UserLoginCheck(user);
        }

        public static string GetContacts(User user)
        {
            return ContactRepository.GetContactsFromDB(user);
        }

        public static string SearchContacts(Contact contact)
        {
            return ContactRepository.SearchContactsFromDB(contact);
        }

        public static bool AddContact(Contact contact)
        {
            return ContactRepository.AddContactToDB(contact);
        }

        public static bool DeleteContact(Contact contact)
        {
            return ContactRepository.DeleteContactFromDB(contact);
        }
    }
}