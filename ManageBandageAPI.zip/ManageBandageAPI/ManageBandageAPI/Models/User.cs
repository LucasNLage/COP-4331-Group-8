﻿namespace ManageBandageAPI.Models
{
    public class User
    {
        public string UserID { get; set; }

        public string Password { get; set; }
    }
}