﻿using ManageBandageAPI.Models;
using ManageBandageAPI.Processors;
using System.Web.Http;

namespace ManageBandageAPI.Controllers
{
    public class ContactsController : ApiController
    {
        [HttpGet]
        [Route("UserLogin")]
        public bool UserLogin(User user)
        {
            if(user == null)
            {
                return false;
            }
            return ContactProcessor.UserLogin(user);
        }

        [HttpGet]
        [Route("GetContacts")]
        public string GetContacts(User user)
        {
            if(user == null)
            {
                return null;
            }
            return ContactProcessor.GetContacts(user);
        }

        [HttpGet]
        [Route("SearchContacts")]
        public string SearchContacts(Contact contact)
        {
            if(contact == null)
            {
                return null;
            }
            return ContactProcessor.SearchContacts(contact);
        }


        [HttpPost]
        [Route("SaveContact")]
        public bool SaveContact(Contact contact)
        {
            if(contact == null)
            {
                return false;
            }
            return ContactProcessor.AddContact(contact);

        }

        [HttpDelete]
        [Route("DeleteContact")]
        public bool DeleteContact(Contact contact)
        {
            if(contact == null)
            {
                return false;
            }
            return ContactProcessor.DeleteContact(contact);
        }
    }
}
