﻿using ManageBandageAPI.Models;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace ManageBandageAPI.Repositories
{
    public class ContactRepository
    {

        public static bool UserLoginCheck(User user)
        {
            var connectionString = "Server=tcp:managebandage.database.windows.net,1433;Initial Catalog=ManageBandage;Persist Security Info=False;User ID='ServerAdmin';Password='Passw0rd';MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            var query = "SELECT * FROM users WHERE users.UserID = '@UserID' AND users.Password = '@Password'";

            query = query.Replace("@UserID", user.UserID).Replace("@Password", user.Password);

            SqlConnection connection = new SqlConnection(connectionString);

            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                var DataReader = command.ExecuteReader();
                var dataTable = new DataTable();
                dataTable.Load(DataReader);
                command.Dispose();
                connection.Close();

                if (dataTable.Rows.Count == 0) return false;
                else return true;
            }
            catch (Exception e)
            {
                throw e;
                //return false;
            }
        }

        public static bool AddContactToDB(Contact contact)
        {
            var connectionString = "Server=tcp:managebandage.database.windows.net,1433;Initial Catalog=ManageBandage;Persist Security Info=False;User ID='ServerAdmin';Password='Passw0rd';MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            var query = "INSERT INTO contacts VALUES ('@UserID' ,'@FirstName' ,'@LastName' , '@PhoneNumber' ,'@Email')";

            query = query.Replace("@UserID", contact.UserID).Replace("@FirstName", contact.FirstName).Replace("@LastName", contact.LastName).Replace("@PhoneNumber", contact.PhoneNumber).Replace("@Email", contact.Email);

            SqlConnection connection = new SqlConnection(connectionString);

            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                command.Dispose();
                connection.Close();
                return true;
            }
            catch (Exception e)
            {
                throw e;
                //return false;
            }

        }

        public static string GetContactsFromDB(User user)
        {
            var connectionString = "Server=tcp:managebandage.database.windows.net,1433;Initial Catalog=ManageBandage;Persist Security Info=False;User ID='ServerAdmin';Password='Passw0rd';MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            var query = "SELECT * FROM contacts WHERE contacts.UserID = '@Username'";

            query = query.Replace("@Username", user.UserID);

            SqlConnection connection = new SqlConnection(connectionString);

            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                var DataReader = command.ExecuteReader();
                var dataTable = new DataTable();
                dataTable.Load(DataReader);
                command.Dispose();
                connection.Close();

                return DataTableToJSONWithStringBuilder(dataTable);
            }
            catch (Exception e)
            {
                throw e;
                //return false;
            }
        }

        public static bool DeleteContactFromDB(Contact contact)
        {
            var connectionString = "Server=tcp:managebandage.database.windows.net,1433;Initial Catalog=ManageBandage;Persist Security Info=False;User ID='ServerAdmin';Password='Passw0rd';MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            var query = "DELETE FROM contacts WHERE contacts.UserID = '@UserID' AND contacts.FirstName = '@FirstName' AND contacts.LastName = '@LastName' AND contacts.PhoneNumber = '@PhoneNumber' AND contacts.Email = '@Email'";

            query = query.Replace("@UserID", contact.UserID).Replace("@FirstName", contact.FirstName).Replace("@LastName", contact.LastName).Replace("@PhoneNumber", contact.PhoneNumber).Replace("@Email", contact.Email);

            SqlConnection connection = new SqlConnection(connectionString);

            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                command.Dispose();
                connection.Close();
                return true;
            }
            catch (Exception e)
            {
                throw e;
                //return false;
            }
        }

        public static string SearchContactsFromDB(Contact contact)
        {
            var connectionString = "Server=tcp:managebandage.database.windows.net,1433;Initial Catalog=ManageBandage;Persist Security Info=False;User ID='ServerAdmin';Password='Passw0rd';MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            var query = "SELECT * FROM contacts WHERE contacts.UserID = '@UserID' AND contacts.FirstName = '@FirstName'";

            query = query.Replace("@UserID", contact.UserID).Replace("@FirstName", contact.FirstName);

            SqlConnection connection = new SqlConnection(connectionString);

            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                var DataReader = command.ExecuteReader();
                var dataTable = new DataTable();
                dataTable.Load(DataReader);
                command.Dispose();
                connection.Close();

                return DataTableToJSONWithStringBuilder(dataTable);
            }
            catch (Exception e)
            {
                throw e;
                //return false;
            }
        }

        public static string DataTableToJSONWithStringBuilder(DataTable table)
        {
            var JSONString = new StringBuilder();
            if (table.Rows.Count > 0)
            {
                JSONString.Append("[");
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    JSONString.Append("{");
                    for (int j = 0; j < table.Columns.Count; j++)
                    {
                        if (j < table.Columns.Count - 1)
                        {
                            JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\":" + "\"" + table.Rows[i][j].ToString() + "\",");
                        }
                        else if (j == table.Columns.Count - 1)
                        {
                            JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\":" + "\"" + table.Rows[i][j].ToString() + "\"");
                        }
                    }
                    if (i == table.Rows.Count - 1)
                    {
                        JSONString.Append("}");
                    }
                    else
                    {
                        JSONString.Append("},");
                    }
                }
                JSONString.Append("]");
            }
            return JSONString.ToString();
        }

    }
}